sap.ui.define(["sap/fe/core/PageController"], function (Controller) {
  "use strict";

  /**
   * @namespace eagleburgmann.training.orders.ext.main
   */
  const Main = Controller.extend("eagleburgmann.training.orders.ext.main.Main", {});
  return Main;
});
//# sourceMappingURL=Main-dbg.controller.js.map
