sap.ui.define(["sap/fe/core/PageController"],function(e){"use strict";const n=e.extend("eagleburgmann.training.orders.ext.main.Main",{});return n});
//# sourceMappingURL=Main.controller.js.map